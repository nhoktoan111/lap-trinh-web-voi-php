<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["name"]) || empty($_POST["email"])) {
        echo "Vui lòng nhập Họ tên và Email";
    } else {
        echo "<h3>Thông tin đã gửi:</h3>";
        echo "Họ tên: " . htmlspecialchars($_POST["name"]) . "<br>";
        echo "Email: " . htmlspecialchars($_POST["email"]) . "<br>";
        echo "Giới tính: " . ($_POST["gender"] ?? "") . "<br>";

        if (!empty($_POST["hobby"])) {
            echo "Sở thích: " . implode(", ", $_POST["hobby"]);
        }
    }
}
?>

<form method="post">
    Họ tên: <input type="text" name="name"><br>
    Email: <input type="email" name="email"><br>

    Giới tính:
    <input type="radio" name="gender" value="Nam"> Nam
    <input type="radio" name="gender" value="Nữ"> Nữ<br>

    Sở thích:
    <input type="checkbox" name="hobby[]" value="Game"> Game
    <input type="checkbox" name="hobby[]" value="Music"> Music
    <input type="checkbox" name="hobby[]" value="Sport"> Sport<br>

    <button type="submit">Submit</button>
</form>
