<?php
/**
 * Bài tập 1: Khai báo biến và in thông tin
 * ---------------------------------------
 * Input: Không có (Dữ liệu được gán cứng vào biến)
 * Output: Hiển thị Họ tên, Lớp, Email ra trình duyệt, mỗi thông tin 1 dòng.
 */

// 1. Khai báo biến
$name = "Ngô Đình Nam";       // Thay tên của bạn
$class = "CNTT_K14_01";       // Thay lớp của bạn
$email = "20220400@eaut.edu.vn"; // Thay email của bạn

// 2. Hiển thị kết quả (Dùng thẻ <h1> cho tiêu đề và <br> để xuống dòng)
echo "<h1>Thông tin sinh viên</h1>";
echo "<b>Họ và tên:</b> " . $name . "<br>";
echo "<b>Lớp:</b> " . $class . "<br>";
echo "<b>Email:</b> " . $email . "<br>";
?>