<?php
/**
 * BT 2: Kiểm tra các kiểu dữ liệu
 * ------------------------------------
 * Input: Không có
 * Output: Thông tin chi tiết (kiểu + giá trị) của 5 biến khác nhau.
 */

// 1. Khai báo 5 kiểu dữ liệu
$type_string = "Hello PHP";   // String
$type_int    = 2024;          // Integer
$type_float  = 9.5;           // Float (Double)
$type_bool   = true;          // Boolean
$type_array  = ["HTML", "CSS", "JS"]; // Array

// 2. Hiển thị (Dùng <ul> <li> để tạo danh sách)
echo "<h1>Kiểm tra kiểu dữ liệu (var_dump)</h1>";
echo "<ul>";

echo "<li>Biến String: ";
var_dump($type_string);
echo "</li>";

echo "<li>Biến Integer: ";
var_dump($type_int);
echo "</li>";

echo "<li>Biến Float: ";
var_dump($type_float);
echo "</li>";

echo "<li>Biến Boolean: ";
var_dump($type_bool);
echo "</li>";

echo "<li>Biến Array: ";
var_dump($type_array);
echo "</li>";

echo "</ul>";
?>