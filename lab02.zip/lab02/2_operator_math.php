<?php
/**
 * Bài tập 3: Toán tử toán học
 * ---------------------------
 * Input: Bán kính r = 10 (Gán cứng)
 * Output: Chu vi và Diện tích hình tròn được format đẹp.
 */

$r = 10;          // Bán kính
$PI = 3.14;       // Số Pi

// Tính toán
$chu_vi   = 2 * $PI * $r;
$dien_tich = $PI * ($r * $r);

// Hiển thị kết quả
echo "<h1>Tính toán Hình Tròn</h1>";
echo "<div>Bán kính (r) = <b>$r</b></div><br>";

echo "<b>Kết quả:</b>";
echo "<ul>";
echo "<li>Chu vi (2 * $PI * $r) = <b>$chu_vi</b></li>";
echo "<li>Diện tích ($PI * $r^2) = <b>$dien_tich</b></li>";
echo "</ul>";
?>