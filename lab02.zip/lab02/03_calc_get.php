<?php
/**
 * Bài tập 4: Tính toán qua URL (GET Method)
 * -----------------------------------------
 * Input: Hai tham số 'a' và 'b' trên thanh địa chỉ URL
 * Output: Kết quả Cộng, Trừ, Nhân, Chia.
 */

// Lấy dữ liệu từ URL. Nếu không nhập thì mặc định là 0
$a = isset($_GET['a']) ? $_GET['a'] : 0;
$b = isset($_GET['b']) ? $_GET['b'] : 0;

// Chuyển sang kiểu số thực để tính toán chính xác
$a = (float)$a;
$b = (float)$b;

echo "<h1>Máy tính cơ bản (GET)</h1>";
echo "<i>Nhập link dạng: ?a=10&b=5 để test</i><br><br>";

echo "<b>Giá trị đầu vào:</b> a = $a, b = $b <hr>";

echo "<b>Kết quả:</b>";
echo "<ul>";
echo "<li>Tổng ($a + $b) = <b>" . ($a + $b) . "</b></li>";
echo "<li>Hiệu ($a - $b) = <b>" . ($a - $b) . "</b></li>";
echo "<li>Tích ($a * $b) = <b>" . ($a * $b) . "</b></li>";

// Kiểm tra chia cho 0
if ($b != 0) {
    echo "<li>Thương ($a / $b) = <b>" . ($a / $b) . "</b></li>";
} else {
    echo "<li>Thương: <b>Không thể chia cho 0</b></li>";
}
echo "</ul>";
?>