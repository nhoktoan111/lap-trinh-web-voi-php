<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bài 1: Xử lý tên</title>
</head>
<body>
    <h3>Danh sách tên</h3>
    <?php
    // Nhận input từ GET, mặc định là chuỗi rỗng nếu không có
    $rawInput = $_GET['names'] ?? '';

    if (trim($rawInput) === '') {
        echo "<p>Chưa có dữ liệu hợp lệ. Vui lòng nhập ?names=... trên URL</p>";
    } else {
        // 1. Tách chuỗi bằng dấu phẩy
        $parts = explode(',', $rawInput);
        
        // 2. Trim từng phần tử và Lọc phần tử rỗng
        $parts = array_map('trim', $parts);
        $cleanNames = array_filter($parts, fn($val) => $val !== '');

        // 3. Hiển thị kết quả
        echo "<p>Chuỗi gốc: " . htmlspecialchars($rawInput) . "</p>";
        echo "<p>Số lượng tên hợp lệ: " . count($cleanNames) . "</p>";

        echo "<ol>";
        foreach ($cleanNames as $name) {
            echo "<li>" . htmlspecialchars($name) . "</li>";
        }
        echo "</ol>";
    }
    ?>
    <p><i>Ví dụ test: ?names=An, Binh, Chi,, Dung</i></p>
</body>
</html>