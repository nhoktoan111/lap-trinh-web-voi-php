<?php
// Yêu cầu file class Student (đã tạo ở Bài 4)
require_once 'Student.php';

// 1. Input đầu vào
$input = "SV001-An-3.2;SV002-Binh-2.6;SV003-Chi-3.5";

// 2. Xử lý dữ liệu (Parse)
$studentList = [];
$records = explode(";", $input); // B1: Tách từng bản ghi

foreach ($records as $rec) {
    if (trim($rec) === '') continue;

    $info = explode("-", $rec); // B2: Tách ID, Name, GPA

    if (count($info) === 3) {
        // B3: Trim và ép kiểu
        $id = trim($info[0]);
        $name = trim($info[1]);
        $gpa = (float)$info[2];

        // B4: Tạo object và thêm vào mảng
        $studentList[] = new Student($id, $name, $gpa);
    }
}

// B6: Lọc danh sách sinh viên Giỏi (GPA >= 3.2)
$goodStudents = array_filter($studentList, fn($s) => $s->getGpa() >= 3.2);

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thực hành 2.15: Mini Student List</title>
    <style>
        body { font-family: sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; max-width: 600px; margin-bottom: 20px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        h3 { border-bottom: 2px solid #007bff; display: inline-block; padding-bottom: 5px; }
    </style>
</head>
<body>

    <h3>1. Danh sách sinh viên (Toàn bộ)</h3>
    <table>
        <tr>
            <th>Name</th>
            <th>GPA</th>
            <th>Rank</th>
        </tr>
        <?php foreach ($studentList as $s): ?>
        <tr>
            <td><?= htmlspecialchars($s->getName()) ?></td>
            <td><?= $s->getGpa() ?></td>
            <td><?= $s->getRank() ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h3>2. Danh sách sinh viên Giỏi (GPA >= 3.2)</h3>
    <?php if (!empty($goodStudents)): ?>
        <table>
            <tr>
                <th>Name</th>
                <th>GPA</th>
                <th>Rank</th>
            </tr>
            <?php foreach ($goodStudents as $s): ?>
            <tr>
                <td><?= htmlspecialchars($s->getName()) ?></td>
                <td><?= $s->getGpa() ?></td>
                <td><strong><?= $s->getRank() ?></strong></td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>Không có sinh viên nào đạt loại Giỏi.</p>
    <?php endif; ?>

</body>
</html>