<?php require_once 'Student.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bài 5: Quản lý sinh viên (Advanced)</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; margin: 20px; max-width: 900px; }
        .input-box { border: 1px solid #ccc; padding: 20px; background: #f9f9f9; border-radius: 5px; }
        textarea { width: 100%; height: 100px; margin-bottom: 10px; font-family: monospace; padding: 5px; }
        .controls { margin-top: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #007bff; color: white; }
        .error { color: red; background: #ffe6e6; padding: 10px; margin-top: 10px; border: 1px solid red; }
        .stats { margin-top: 20px; padding: 15px; background: #e9ecef; border-left: 5px solid #28a745; }
    </style>
</head>
<body>
    <h2>Student Manager (Parse - Filter - Sort)</h2>

    <?php
    // Khởi tạo giá trị mặc định
    // Dữ liệu mẫu ban đầu để người dùng dễ test
    $defaultData = "SV001-Nguyen Van An-3.2;SV002-Tran Thi Binh-2.6;SV003-Le Van Chi-3.5;SV004-Pham Dung-3.9;SV005-Doan E-1.8";
    
    $rawInput = $_POST['data'] ?? $defaultData;
    $threshold = $_POST['threshold'] ?? '';
    $isSort = isset($_POST['sort']);
    $students = [];
    $errorMsg = "";

    // XỬ LÝ KHI NGƯỜI DÙNG NHẤN "PARSE & SHOW"
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        // 1. Parse dữ liệu từ chuỗi
        if (trim($rawInput) !== '') {
            // Tách các bản ghi bằng dấu chấm phẩy (;)
            $records = explode(';', $rawInput);
            
            foreach ($records as $rec) {
                // Tách các trường bằng dấu gạch ngang (-)
                // Format: ID-Name-GPA
                $parts = explode('-', trim($rec));
                
                // Validate: Phải đủ 3 phần và GPA phải là số
                if (count($parts) === 3 && is_numeric($parts[2])) {
                    $id = trim($parts[0]);
                    $name = trim($parts[1]);
                    $gpa = (float)$parts[2];
                    
                    $students[] = new Student($id, $name, $gpa);
                }
            }
        }

        // 2. Kiểm tra danh sách rỗng (Nếu parse không được dòng nào hoặc input rỗng)
        if (empty($students)) {
            $errorMsg = "Không tìm thấy dữ liệu hợp lệ! Vui lòng kiểm tra đúng định dạng: ID-Name-GPA";
        } else {
            // 3. Lọc (Filter) theo Threshold
            if (is_numeric($threshold)) {
                $students = array_filter($students, fn($s) => $s->getGpa() >= (float)$threshold);
            }

            // 4. Sắp xếp (Sort) GPA giảm dần
            if ($isSort) {
                usort($students, fn($a, $b) => $b->getGpa() <=> $a->getGpa());
            }
        }
    }
    ?>

    <div class="input-box">
        <form method="POST">
            <label><strong>Nhập dữ liệu sinh viên (Định dạng: ID-Name-GPA;...)</strong></label><br>
            <textarea name="data"><?= htmlspecialchars($rawInput) ?></textarea>
            
            <div class="controls">
                <label>Lọc GPA >= </label>
                <input type="number" step="0.1" name="threshold" value="<?= htmlspecialchars($threshold) ?>" style="width: 80px;">
                
                <label style="margin-left: 20px; cursor: pointer;">
                    <input type="checkbox" name="sort" <?= $isSort ? 'checked' : '' ?>> Sắp xếp GPA giảm dần
                </label>
                
                <button type="submit" style="margin-left: 20px; padding: 5px 15px; cursor: pointer; background: #28a745; color: white; border: none;">Parse & Show</button>
            </div>
        </form>
    </div>

    <?php if ($errorMsg): ?>
        <div class="error"><?= $errorMsg ?></div>
    <?php endif; ?>

    <?php if (!empty($students)): 
        // Tính toán thống kê
        $gpaList = array_map(fn($s) => $s->getGpa(), $students);
        $avg = array_sum($gpaList) / count($gpaList);
        $max = max($gpaList);
        $min = min($gpaList);
        
        // Thống kê Rank
        $rankStats = [];
        foreach ($students as $s) {
            $r = $s->getRank();
            if (!isset($rankStats[$r])) $rankStats[$r] = 0;
            $rankStats[$r]++;
        }
    ?>
        <h3>Danh sách sinh viên (<?= count($students) ?>)</h3>
        <table>
            <thead>
                <tr>
                    <th>STT</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>GPA</th>
                    <th>Rank</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $index => $s): ?>
                <tr>
                    <td><?= $index + 1 ?></td>
                    <td><?= htmlspecialchars($s->getId()) ?></td>
                    <td><?= htmlspecialchars($s->getName()) ?></td>
                    <td><?= $s->getGpa() ?></td>
                    <td><?= $s->getRank() ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="stats">
            <strong>THỐNG KÊ LỚP HỌC:</strong><br>
            <ul>
                <li>GPA Trung bình: <strong><?= number_format($avg, 2) ?></strong></li>
                <li>GPA Cao nhất: <strong><?= $max ?></strong> | Thấp nhất: <strong><?= $min ?></strong></li>
                <li>Xếp loại: 
                    <?php 
                    foreach ($rankStats as $r => $count) {
                        echo "$r ($count); ";
                    }
                    ?>
                </li>
            </ul>
        </div>
    <?php endif; ?>

</body>
</html>