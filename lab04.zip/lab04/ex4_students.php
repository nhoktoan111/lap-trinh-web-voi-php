<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bài 4: Quản lý sinh viên</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; margin: 30px; }
        h3 { color: #2c3e50; }
        
        table { 
            border-collapse: collapse; 
            width: 100%; 
            max-width: 800px; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        th, td { 
            border: 1px solid #ddd; 
            padding: 12px; 
            text-align: left; 
        }
        
        th { background-color: #3498db; color: white; }
        tr:nth-child(even) { background-color: #f8f9fa; }
        
        /* Tô màu xếp loại cho sinh động */
        .rank-xs { color: #8e44ad; font-weight: bold; } /* Xuất sắc */
        .rank-g { color: #27ae60; font-weight: bold; }  /* Giỏi */
        .rank-k { color: #2980b9; font-weight: bold; }  /* Khá */
        .rank-tb { color: #d35400; }                    /* TB */
        .rank-y { color: #c0392b; }                     /* Yếu */

        .stats-box {
            margin-top: 20px;
            padding: 15px;
            background-color: #ecf0f1;
            border-left: 5px solid #2c3e50;
            width: fit-content;
        }
    </style>
</head>
<body>
    <?php
    require_once 'Student.php';

    // 1. Tạo danh sách sinh viên với TÊN THẬT
    $students = [
        new Student("2021001", "Nguyễn Thùy Linh", 3.85),
        new Student("2021002", "Trần Minh Đức", 3.4),
        new Student("2021003", "Lê Hoàng Nam", 2.9),
        new Student("2021004", "Phạm Thị Thanh Hằng", 3.15),
        new Student("2021005", "Đỗ Quang Khải", 1.8),
        new Student("2021006", "Hoàng Ngọc Lan", 2.6),
        new Student("2021007", "Vũ Tuấn Anh", 3.65),
    ];

    // 2. Tính GPA trung bình
    $totalGpa = 0;
    foreach ($students as $s) {
        $totalGpa += $s->getGpa();
    }
    $avgGpa = count($students) > 0 ? $totalGpa / count($students) : 0;

    // 3. Helper function để tô màu rank (Optional)
    function getRankClass($rank) {
        return match($rank) {
            'Xuất sắc' => 'rank-xs',
            'Giỏi' => 'rank-g',
            'Khá' => 'rank-k',
            'Trung bình' => 'rank-tb',
            default => 'rank-y'
        };
    }
    ?>

    <h3>Danh sách bảng điểm sinh viên</h3>
    <table>
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã SV</th>
                <th>Họ và Tên</th>
                <th>GPA</th>
                <th>Xếp loại</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($students as $i => $s): 
                $rank = $s->getRank();
                $rankClass = getRankClass($rank);
            ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><?= htmlspecialchars($s->getId()) ?></td>
                <td><?= htmlspecialchars($s->getName()) ?></td>
                <td><?= number_format($s->getGpa(), 2) ?></td>
                <td class="<?= $rankClass ?>"><?= $rank ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="stats-box">
        <strong>Thống kê lớp học:</strong><br>
        - Tổng số sinh viên: <?= count($students) ?><br>
        - Điểm trung bình (GPA) cả lớp: <?= number_format($avgGpa, 2) ?>
    </div>
</body>
</html>