<?php
class Product {
    public function __construct(
        private string $id,
        private string $name,
        private float $price,
        private int $qty
    ) {}

    public function getId() { return $this->id; }
    public function getName() { return $this->name; }
    public function getPrice() { return $this->price; }
    public function getQty() { return $this->qty; }
    
    // Tính amount
    public function getAmount() { 
        // Nếu qty âm thì tính bằng 0 hoặc xử lý theo logic kinh doanh
        return $this->price * max(0, $this->qty); 
    }

    public function isValidQty() {
        return $this->qty > 0;
    }
}
?>