<?php require_once 'Product.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bài 6B: Quản lý bán hàng</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; margin: 20px; max-width: 900px; }
        .input-section { background: #f4f4f4; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        textarea { width: 100%; height: 80px; margin-bottom: 10px; font-family: monospace; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #007bff; color: white; }
        .invalid { color: red; font-weight: bold; font-style: italic; font-size: 0.9em; }
        .stats-box { margin-top: 20px; padding: 15px; background: #e2e3e5; border-left: 5px solid #383d41; }
        button { padding: 5px 15px; background: #28a745; color: white; border: none; cursor: pointer; }
        button:hover { background: #218838; }
    </style>
</head>
<body>
    <h2>Hệ thống quản lý bán hàng (Mini)</h2>

    <?php
    // Dữ liệu mẫu (Giữ nguyên format nhập nhưng hiển thị kết quả là tiếng Việt)
    $defaultData = "P001-Noi com dien-120-2;P002-Am sieu toc-45-1;P003-May xay sinh to-80-3;P004-Ban la-30-0";
    
    $rawInput = $_POST['data'] ?? $defaultData;
    $minPrice = $_POST['minPrice'] ?? '';
    $sortAmount = isset($_POST['sort']);
    
    $products = [];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (trim($rawInput) !== '') {
            $records = explode(';', $rawInput);

            foreach ($records as $rec) {
                // Format: ID-Tên-Giá-SốLượng
                $parts = explode('-', trim($rec));

                if (count($parts) === 4 && is_numeric($parts[2]) && is_numeric($parts[3])) {
                    $products[] = new Product(
                        trim($parts[0]),
                        trim($parts[1]),
                        (float)$parts[2],
                        (int)$parts[3]
                    );
                }
            }
        }

        // Lọc theo giá tối thiểu
        if (is_numeric($minPrice)) {
            $products = array_filter($products, fn($p) => $p->getPrice() >= (float)$minPrice);
        }

        // Sắp xếp theo Thành tiền giảm dần
        if ($sortAmount) {
            usort($products, fn($a, $b) => $b->getAmount() <=> $a->getAmount());
        }
    }
    ?>

    <div class="input-section">
        <form method="POST">
            <label><strong>Nhập dữ liệu (Mã-Tên-Giá-SL;...):</strong></label>
            <textarea name="data"><?= htmlspecialchars($rawInput) ?></textarea>
            
            <label>Giá tối thiểu (Lọc):</label>
            <input type="number" name="minPrice" value="<?= htmlspecialchars($minPrice) ?>" style="width: 80px;">
            
            <label style="margin-left: 15px; cursor: pointer;">
                <input type="checkbox" name="sort" <?= $sortAmount ? 'checked' : '' ?>> Sắp xếp Thành tiền giảm dần
            </label>
            
            <button type="submit" style="margin-left: 15px;">Xử lý hiển thị</button>
        </form>
    </div>

    <?php if (!empty($products)): 
        $totalMoney = 0;
        $totalPrice = 0;
        $maxAmountProduct = null;

        foreach ($products as $p) {
            $amt = $p->getAmount();
            $totalMoney += $amt;
            $totalPrice += $p->getPrice();

            if ($maxAmountProduct === null || $amt > $maxAmountProduct->getAmount()) {
                $maxAmountProduct = $p;
            }
        }
        $avgPrice = count($products) > 0 ? $totalPrice / count($products) : 0;
    ?>
        <h3>Danh sách sản phẩm (<?= count($products) ?>)</h3>
        <table>
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã SP</th>
                    <th>Tên sản phẩm</th>
                    <th>Đơn giá</th>
                    <th>Số lượng</th>
                    <th>Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $i => $p): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= htmlspecialchars($p->getId()) ?></td>
                    <td><?= htmlspecialchars($p->getName()) ?></td>
                    <td><?= number_format($p->getPrice()) ?></td>
                    <td>
                        <?= $p->getQty() ?>
                        <?php if ($p->getQty() <= 0) echo '<span class="invalid"> (SL không hợp lệ)</span>'; ?>
                    </td>
                    <td><?= number_format($p->getAmount()) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="stats-box">
            <strong>THỐNG KÊ:</strong><br>
            - Tổng doanh thu: <strong><?= number_format($totalMoney) ?></strong><br>
            - Đơn giá trung bình: <strong><?= number_format($avgPrice, 2) ?></strong><br>
            - Sản phẩm có doanh thu cao nhất: 
                <strong><?= htmlspecialchars($maxAmountProduct->getName()) ?></strong> 
                (<?= number_format($maxAmountProduct->getAmount()) ?>)
        </div>
    <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <p style="color: red;">Không tìm thấy dữ liệu hợp lệ!</p>
    <?php endif; ?>

</body>
</html>