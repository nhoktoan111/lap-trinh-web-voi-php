<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bài 2: Mảng điểm</title>
</head>
<body>
    <h3>Thống kê điểm số</h3>
    <?php
    // 1. Khai báo mảng điểm
    $scores = [8.5, 7.0, 9.25, 6.5, 8.0, 5.75];

    // 2. Tính trung bình
    $avg = array_sum($scores) / count($scores);
    
    // 3. Đếm điểm >= 8.0
    $goodScores = array_filter($scores, fn($s) => $s >= 8.0);
    
    // 4. Max, Min
    $maxScore = max($scores);
    $minScore = min($scores);

    // 5. Sắp xếp (copy mảng để không mất dữ liệu gốc)
    $ascScores = $scores; sort($ascScores);
    $descScores = $scores; rsort($descScores);

    // Hiển thị
    echo "<p>Mảng gốc: [" . implode(", ", $scores) . "]</p>";
    echo "<p>Điểm trung bình: " . number_format($avg, 2) . "</p>";
    echo "<p>Số lượng điểm >= 8.0: " . count($goodScores) . " (Danh sách: " . implode(", ", $goodScores) . ")</p>";
    echo "<p>Điểm cao nhất: $maxScore | Thấp nhất: $minScore</p>";
    echo "<p>Sắp xếp tăng dần: [" . implode(", ", $ascScores) . "]</p>";
    echo "<p>Sắp xếp giảm dần: [" . implode(", ", $descScores) . "]</p>";
    ?>
</body>
</html>