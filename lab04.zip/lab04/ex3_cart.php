<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bài 3: Giỏ hàng (VNĐ)</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; max-width: 900px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #007bff; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .text-right { text-align: right; }
        .total-row { background-color: #e9ecef; font-weight: bold; font-size: 1.1em; }
        .highlight { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
    <h2>Chi tiết đơn hàng (VNĐ)</h2>

    <?php
    // Hàm helper để render HTML an toàn
    function h($str) {
        return htmlspecialchars($str);
    }

    // Hàm format tiền Việt: dùng dấu chấm (.) phân cách hàng nghìn
    function formatVND($number) {
        return number_format($number, 0, ',', '.');
    }

    // 1. Khai báo mảng products với giá tiền Việt Nam
    $products = [
        ['name' => 'iPhone 15 Pro Max', 'price' => 34990000, 'qty' => 1],
        ['name' => 'Samsung Galaxy S24', 'price' => 23990000, 'qty' => 2],
        ['name' => 'MacBook Air M2',    'price' => 26500000, 'qty' => 1],
        ['name' => 'Chuột Logitech MX', 'price' => 2100000,  'qty' => 5],
        ['name' => 'Bàn phím Keychron', 'price' => 3200000,  'qty' => 3],
        ['name' => 'Màn hình Dell Ultra','price' => 9500000,  'qty' => 2],
        ['name' => 'Tai nghe Sony WH',  'price' => 6990000,  'qty' => 4],
        ['name' => 'Lót chuột size lớn','price' => 350000,   'qty' => 10],
    ];

    // 2. Tạo cột amount = price * qty
    $products = array_map(function($p) {
        $p['amount'] = $p['price'] * $p['qty'];
        return $p;
    }, $products);

    // 3. Sắp xếp danh sách theo Price giảm dần
    usort($products, fn($a, $b) => $b['price'] <=> $a['price']);

    // 4. Tính tổng tiền đơn hàng
    $totalMoney = array_reduce($products, fn($sum, $item) => $sum + $item['amount'], 0);

    // 5. Tìm sản phẩm có Amount lớn nhất
    $maxItem = array_reduce($products, function($carry, $item) {
        return ($carry === null || $item['amount'] > $carry['amount']) ? $item : $carry;
    });
    ?>

    <table>
        <thead>
            <tr>
                <th style="width: 50px;">STT</th>
                <th>Tên sản phẩm</th>
                <th class="text-right">Đơn giá (VNĐ)</th>
                <th class="text-right" style="width: 80px;">SL</th>
                <th class="text-right">Thành tiền (VNĐ)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products as $index => $p): ?>
            <tr>
                <td style="text-align: center;"><?= $index + 1 ?></td>
                <td><?= h($p['name']) ?></td>
                <td class="text-right"><?= formatVND($p['price']) ?></td>
                <td class="text-right"><?= $p['qty'] ?></td>
                <td class="text-right"><?= formatVND($p['amount']) ?></td>
            </tr>
            <?php endforeach; ?>
            
            <tr class="total-row">
                <td colspan="4" class="text-right">TỔNG CỘNG:</td>
                <td class="text-right"><?= formatVND($totalMoney) ?> đ</td>
            </tr>
        </tbody>
    </table>

    <div style="margin-top: 20px; padding: 15px; border-left: 5px solid #007bff; background: #f8f9fa;">
        <strong>Thống kê:</strong><br>
        Sản phẩm mang lại doanh thu cao nhất: 
        <span class="highlight"><?= h($maxItem['name']) ?></span> 
        (Tổng: <?= formatVND($maxItem['amount']) ?> đ)
    </div>

</body>
</html>