<?php
class Student {
    // Constructor Promotion (PHP 8.x)
    public function __construct(
        private string $id,
        private string $name,
        private float $gpa
    ) {}

    public function getId() { return $this->id; }
    public function getName() { return $this->name; }
    public function getGpa() { return $this->gpa; }

    public function getRank(): string {
        if ($this->gpa >= 3.2) return "Giỏi";
        if ($this->gpa >= 2.5) return "Khá";
        return "Trung bình";
    }
}
?>