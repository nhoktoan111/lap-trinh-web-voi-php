<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/flash.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_verify($_POST['csrf'] ?? null)) {
    // Xóa session
    session_unset();
    session_destroy();

    // Xóa cookie remember [cite: 35]
    setcookie('remember_username', '', time() - 3600, '/');

    // Start session mới để lưu flash message
    session_start();
    set_flash('info', 'Bạn đã đăng xuất.');
    header('Location: login.php');
    exit;
} else {
    // Nếu truy cập trực tiếp vào file này mà không qua POST
    header('Location: dashboard.php');
    exit;
}
?>