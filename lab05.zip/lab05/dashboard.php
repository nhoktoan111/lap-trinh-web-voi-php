<?php
require_once __DIR__ . '/includes/auth.php';
require_login(); // Bảo vệ trang [cite: 31]
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/csrf.php'; // Để tạo token cho logout ở header
?>

<h2>Dashboard</h2>
<p>Xin chào, <strong><?php echo htmlspecialchars($_SESSION['user']['username']); ?></strong>!</p>
<p>Vai trò của bạn: <?php echo htmlspecialchars($_SESSION['user']['role']); ?></p>

<p>Hãy truy cập <a href="products.php">Danh sách sản phẩm</a> để mua sắm.</p>

</body></html>