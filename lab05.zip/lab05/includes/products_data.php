<?php
// includes/products_data.php

$products = [
    1 => [
        'name' => 'iPhone 15 Pro Max', 
        'price' => 34000000, 
        // Ảnh cũ (Vẫn hoạt động tốt)
        'image' => 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&q=80&w=400',
        'desc' => 'Titanium tự nhiên, chip A17 Pro mạnh mẽ.'
    ],
    2 => [
        'name' => 'Samsung Galaxy S24 Ultra', 
        'price' => 30000000, 
        // ĐÃ ĐỔI LINK MỚI (Ảnh điện thoại cầm tay)
        'image' => 'https://tse4.mm.bing.net/th/id/OIP.67P4CLNOPwSCPeCvKJ0_gQHaHd?pid=Api&P=0&h=220',
        'desc' => 'Quyền năng Galaxy AI, Zoom mắt thần.'
    ],
    3 => [
        'name' => 'MacBook Air M3', 
        'price' => 27000000, 
        // ĐÃ ĐỔI LINK MỚI (Ảnh Laptop trên bàn làm việc)
        'image' => 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&q=80&w=400',
        'desc' => 'Mỏng nhẹ, chip M3 xử lý siêu nhanh.'
    ],
    4 => [
        'name' => 'Sony WH-1000XM5', 
        'price' => 8500000, 
        // Ảnh cũ (Vẫn hoạt động tốt)
        'image' => 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?auto=format&fit=crop&q=80&w=400',
        'desc' => 'Chống ồn đỉnh cao, âm thanh Hi-Res.'
    ],
    5 => [
        'name' => 'iPad Pro M4 11 inch', 
        'price' => 28000000, 
        // Ảnh cũ (Vẫn hoạt động tốt)
        'image' => 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&q=80&w=400',
        'desc' => 'Màn hình OLED 2 lớp, siêu mỏng.'
    ],
    6 => [
        'name' => 'Apple Watch Series 9', 
        'price' => 10000000, 
        // Ảnh cũ (Vẫn hoạt động tốt)
        'image' => 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&q=80&w=400',
        'desc' => 'Chạm hai lần, màn hình sáng hơn.'
    ],
    7 => [
        'name' => 'Marshall Stanmore III', 
        'price' => 9500000, 
        // ĐÃ ĐỔI LINK MỚI (Ảnh loa rõ nét hơn)
        'image' => 'https://tse3.mm.bing.net/th/id/OIP.80flLCKYHnjYSsv1BCNGXwHaEv?pid=Api&P=0&h=220',
        'desc' => 'Âm thanh huyền thoại, thiết kế cổ điển.'
    ],
    8 => [
        'name' => 'Bàn phím Keychron K2 Pro', 
        'price' => 2500000, 
        // Ảnh cũ (Vẫn hoạt động tốt)
        'image' => 'https://images.unsplash.com/photo-1595225476474-87563907a212?auto=format&fit=crop&q=80&w=400',
        'desc' => 'Cơ học, custom, gõ siêu sướng.'
    ]
];
?>