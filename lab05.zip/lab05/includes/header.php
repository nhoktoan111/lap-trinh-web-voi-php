<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/auth.php';
// Kiểm tra file tồn tại trước khi require để tránh lỗi nếu bạn chưa tạo file csrf.php
if (file_exists(__DIR__ . '/csrf.php')) {
    require_once __DIR__ . '/csrf.php';
}
require_once __DIR__ . '/flash.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop Demo - Lab 05</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        /* --- RESET & GLOBAL --- */
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: #f9fafb; /* Màu nền xám rất nhạt */
            color: #1f2937; /* Màu chữ đen xám dịu mắt */
            line-height: 1.6;
            margin: 0;
        }

        /* --- NAVIGATION BAR --- */
        header {
            background: #ffffff;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            position: sticky;
            top: 0;
            z-index: 50;
        }

        nav {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        /* Logo / Brand Name */
        .nav-brand {
            font-size: 1.25rem;
            font-weight: 700;
            color: #111827;
            text-decoration: none;
            letter-spacing: -0.025em;
        }

        /* Nav Links Group */
        .nav-links {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .nav-link {
            text-decoration: none;
            color: #4b5563;
            font-weight: 500;
            font-size: 0.95rem;
            transition: color 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            color: #2563eb; /* Màu xanh dương hiện đại */
        }

        /* Badge số lượng giỏ hàng */
        .cart-count {
            background-color: #ef4444;
            color: white;
            font-size: 0.75rem;
            padding: 2px 6px;
            border-radius: 9999px;
            margin-left: 4px;
            vertical-align: middle;
        }

        /* Nút Logout */
        .btn-logout {
            background-color: #f3f4f6;
            border: 1px solid #e5e7eb;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-family: inherit;
            font-weight: 500;
            font-size: 0.875rem;
            color: #374151;
            transition: all 0.2s;
        }

        .btn-logout:hover {
            background-color: #e5e7eb;
            color: #111827;
        }

        /* --- MAIN CONTENT CONTAINER --- */
        /* Thêm class này vào body các trang con để căn giữa nội dung */
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }

        /* --- FLASH MESSAGES --- */
        .flash-container {
            max-width: 1200px;
            margin: 20px auto 0;
            padding: 0 20px;
        }

        .flash {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .success { background-color: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
        .error   { background-color: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
        .info    { background-color: #eff6ff; color: #1e40af; border: 1px solid #bfdbfe; }

        /* --- TABLE STYLES (Dùng chung cho đẹp) --- */
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        
        th {
            background-color: #f8fafc;
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        
        td {
            padding: 16px;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
        }

        tr:last-child td { border-bottom: none; }
    </style>
</head>
<body>

    <header>
        <nav>
            <a href="dashboard.php" class="nav-brand">Cửa hàng công nghệ</a>

            <div class="nav-links">
                <?php if (is_logged_in()): ?>
                    <a href="dashboard.php" class="nav-link">Dashboard</a>
                    <a href="products.php" class="nav-link">Sản phẩm</a>
                    <a href="cart.php" class="nav-link">
                        Giỏ hàng 
                        <?php 
                        $count = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; // Đếm tổng số lượng item
                        if ($count > 0): ?>
                            <span class="cart-count"><?php echo $count; ?></span>
                        <?php endif; ?>
                    </a>

                    <form action="logout.php" method="POST" style="margin-left: 10px;">
                        <?php if (function_exists('csrf_token')): ?>
                            <input type="hidden" name="csrf" value="<?php echo csrf_token(); ?>">
                        <?php endif; ?>
                        <button type="submit" class="btn-logout">
                            Đăng xuất (<?php echo htmlspecialchars($_SESSION['user']['username'] ?? 'User'); ?>)
                        </button>
                    </form>

                <?php else: ?>
                    <a href="login.php" class="nav-link" style="color: #2563eb;">Đăng nhập</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <div class="flash-container">
        <?php 
        if (function_exists('get_flash')) {
            if ($msg = get_flash('success')) echo "<div class='flash success'> $msg</div>";
            if ($msg = get_flash('error')) echo "<div class='flash error'>⚠️ $msg</div>";
            if ($msg = get_flash('info')) echo "<div class='flash info'>ℹ️ $msg</div>";
        }
        ?> 
    </div>

    <div class="container">