<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/flash.php';

// --- LOGIC XỬ LÝ ĐĂNG NHẬP (GIỮ NGUYÊN) ---

// Xử lý Remember Me: Nếu đã có cookie thì tự login
if (!is_logged_in() && isset($_COOKIE['remember_username'])) {
    $username = $_COOKIE['remember_username'];
    // Lưu ý: Biến $users cần được định nghĩa trong auth.php hoặc tại đây
    if (isset($users[$username])) {
        $_SESSION['auth'] = true;
        $_SESSION['user'] = ['username' => $username, 'role' => $users[$username]['role']];
        set_flash('success', 'Chào mừng trở lại (via Cookie)!');
        header('Location: dashboard.php');
        exit;
    }
}

// Nếu đã login rồi thì vào dashboard luôn
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (isset($users[$username]) && password_verify($password, $users[$username]['hash'])) {
        // Login thành công
        $_SESSION['auth'] = true;
        $_SESSION['user'] = ['username' => $username, 'role' => $users[$username]['role']];
        
        // Khởi tạo giỏ hàng nếu chưa có
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        
        // Xử lý Remember Me (Checkbox)
        if (!empty($_POST['remember'])) {
            setcookie('remember_username', $username, time() + 7*24*60*60, '/'); // 7 ngày
        }

        set_flash('success', 'Đăng nhập thành công.');
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Tài khoản hoặc mật khẩu không đúng.';
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<style>
    .login-wrapper {
        min-height: 80vh; /* Căn giữa theo chiều dọc */
        display: flex;
        align-items: center;
        justify-content: center;
        padding-bottom: 50px;
    }

    .login-card {
        background: #ffffff;
        width: 100%;
        max-width: 400px;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }

    .login-title {
        text-align: center;
        font-size: 1.5rem;
        font-weight: 700;
        color: #111827;
        margin-bottom: 25px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-label {
        display: block;
        font-size: 0.875rem;
        font-weight: 500;
        color: #374151;
        margin-bottom: 8px;
    }

    .form-input {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #d1d5db;
        border-radius: 6px;
        font-size: 0.95rem;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    .form-input:focus {
        outline: none;
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
    }

    .checkbox-wrapper {
        display: flex;
        align-items: center;
        margin-bottom: 25px;
    }

    .checkbox-input {
        width: 16px;
        height: 16px;
        margin-right: 8px;
        cursor: pointer;
    }

    .checkbox-label {
        font-size: 0.875rem;
        color: #4b5563;
        cursor: pointer;
    }

    .btn-submit {
        width: 100%;
        background-color: #2563eb;
        color: white;
        padding: 12px;
        border: none;
        border-radius: 6px;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        transition: background-color 0.2s;
    }

    .btn-submit:hover {
        background-color: #1d4ed8;
    }

    .login-hint {
        margin-top: 20px;
        font-size: 0.85rem;
        color: #6b7280;
        text-align: center;
        background: #f9fafb;
        padding: 10px;
        border-radius: 6px;
        border: 1px dashed #d1d5db;
    }
    
    .error-alert {
        background-color: #fef2f2;
        border: 1px solid #fecaca;
        color: #991b1b;
        padding: 12px;
        border-radius: 6px;
        margin-bottom: 20px;
        font-size: 0.9rem;
        text-align: center;
    }
</style>

<div class="login-wrapper">
    <div class="login-card">
        <h2 class="login-title">Đăng nhập hệ thống</h2>

        <?php if ($error): ?>
            <div class="error-alert">
                ⚠️ <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="username" class="form-label">Tên đăng nhập</label>
                <input type="text" id="username" name="username" class="form-input" 
                       value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" 
                       required autofocus placeholder="Nhập username...">
            </div>

            <div class="form-group">
                <label for="password" class="form-label">Mật khẩu</label>
                <input type="password" id="password" name="password" class="form-input" 
                       required placeholder="••••••••">
            </div>

            <div class="checkbox-wrapper">
                <input type="checkbox" id="remember" name="remember" class="checkbox-input">
                <label for="remember" class="checkbox-label">Ghi nhớ đăng nhập (7 ngày)</label>
            </div>

            <button type="submit" class="btn-submit">Đăng nhập ngay</button>
        </form>

        <div class="login-hint">
            <strong>Gợi ý demo:</strong><br>
            admin / admin123<br>
            student / student123
        </div>
    </div>
</div>

</body>
</html>