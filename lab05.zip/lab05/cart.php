<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/flash.php';
// THAY ĐỔI QUAN TRỌNG: Gọi file dữ liệu chung thay vì khai báo mảng tại đây
require_once __DIR__ . '/includes/products_data.php'; 

require_login();

// Xử lý cập nhật/xóa
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_cart'])) {
        foreach ($_POST['qty'] as $pid => $qty) {
            $qty = (int)$qty;
            if ($qty <= 0) {
                unset($_SESSION['cart'][$pid]);
            } else {
                $_SESSION['cart'][$pid] = $qty;
            }
        }
        set_flash('success', 'Đã cập nhật giỏ hàng.');
    } elseif (isset($_POST['empty_cart'])) {
        $_SESSION['cart'] = [];
        set_flash('info', 'Đã xóa toàn bộ giỏ hàng.');
    }
    header('Location: cart.php');
    exit;
}

require_once __DIR__ . '/includes/header.php';
$cart = $_SESSION['cart'] ?? [];
$total = 0;
?>

<h2>Giỏ hàng của bạn</h2>
<?php if (empty($cart)): ?>
    <div style="text-align: center; padding: 50px;">
        <p>Giỏ hàng đang trống trơn.</p>
        <a href="products.php" style="background: #007bff; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Quay lại mua sắm ngay</a>
    </div>
<?php else: ?>
    <form method="POST" action="">
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
            <tr style="background: #f8f9fa;">
                <th style="padding: 12px; border: 1px solid #dee2e6;">Hình ảnh</th>
                <th style="padding: 12px; border: 1px solid #dee2e6;">Sản phẩm</th>
                <th style="padding: 12px; border: 1px solid #dee2e6;">Giá</th>
                <th style="padding: 12px; border: 1px solid #dee2e6;">Số lượng</th>
                <th style="padding: 12px; border: 1px solid #dee2e6;">Thành tiền</th>
            </tr>
            <?php foreach ($cart as $id => $qty): 
                // Kiểm tra xem ID trong giỏ hàng có tồn tại trong dữ liệu chung không
                if (!isset($products[$id])) continue;
                $p = $products[$id];
                $subtotal = $p['price'] * $qty;
                $total += $subtotal;
            ?>
            <tr>
                <td style="padding: 12px; border: 1px solid #dee2e6; text-align: center;">
                    <img src="<?php echo $p['image']; ?>" alt="" style="width: 50px; height: 50px; object-fit: contain;">
                </td>
                <td style="padding: 12px; border: 1px solid #dee2e6; font-weight: bold;">
                    <?php echo htmlspecialchars($p['name']); ?>
                </td>
                <td style="padding: 12px; border: 1px solid #dee2e6;">
                    <?php echo number_format($p['price']); ?> đ
                </td>
                <td style="padding: 12px; border: 1px solid #dee2e6; text-align: center;">
                    <input type="number" name="qty[<?php echo $id; ?>]" value="<?php echo $qty; ?>" min="0" style="width: 60px; padding: 5px; text-align: center;">
                </td>
                <td style="padding: 12px; border: 1px solid #dee2e6; color: #d9534f; font-weight: bold;">
                    <?php echo number_format($subtotal); ?> đ
                </td>
            </tr>
            <?php endforeach; ?>
            <tr style="background: #fff3cd;">
                <td colspan="4" style="padding: 12px; text-align:right; border: 1px solid #dee2e6;"><strong>Tổng thanh toán:</strong></td>
                <td style="padding: 12px; border: 1px solid #dee2e6; color: #d9534f; font-size: 1.2em;"><strong><?php echo number_format($total); ?> đ</strong></td>
            </tr>
        </table>
        
        <div style="text-align: right;">
            <a href="products.php" style="margin-right: 15px; text-decoration: none; color: #007bff;">← Tiếp tục mua sắm</a>
            <button type="submit" name="update_cart" style="padding: 10px 20px; background: #17a2b8; color: white; border: none; border-radius: 5px; cursor: pointer;">Cập nhật</button>
            <button type="submit" name="empty_cart" onclick="return confirm('Bạn chắc chắn muốn xóa hết?');" style="padding: 10px 20px; background: #dc3545; color: white; border: none; border-radius: 5px; cursor: pointer; margin-left: 10px;">Xóa giỏ hàng</button>
        </div>
    </form>
<?php endif; ?>
</body></html>