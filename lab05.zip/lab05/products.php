<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/flash.php';
require_once __DIR__ . '/includes/products_data.php'; // Nạp dữ liệu mới
require_login();

// Xử lý thêm vào giỏ hàng
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $id = (int)$_POST['product_id'];
    if (isset($products[$id])) {
        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
        $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
        set_flash('success', "Đã thêm <b>{$products[$id]['name']}</b> vào giỏ.");
    }
    header('Location: products.php');
    exit;
}

require_once __DIR__ . '/includes/header.php';
?>

<style>
    /* CSS cho giao diện lưới sản phẩm */
    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 25px;
        margin-top: 20px;
    }
    .product-card {
        background: #fff;
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        overflow: hidden;
        transition: transform 0.2s, box-shadow 0.2s;
        display: flex;
        flex-direction: column;
    }
    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        border-color: #007bff;
    }
    .card-img {
        width: 100%;
        height: 200px;
        object-fit: contain; /* Giữ ảnh không bị méo */
        background: #f9f9f9;
        padding: 10px;
        box-sizing: border-box;
    }
    .card-body {
        padding: 15px;
        flex-grow: 1;
        display: flex;
        flex-direction: column;
    }
    .card-title {
        margin: 0 0 10px 0;
        font-size: 1.1em;
        color: #333;
        font-weight: bold;
    }
    .card-desc {
        color: #666;
        font-size: 0.9em;
        margin-bottom: 15px;
        flex-grow: 1;
    }
    .card-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: auto;
    }
    .price {
        color: #d9534f;
        font-weight: bold;
        font-size: 1.1em;
    }
    .btn-add {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 6px;
        cursor: pointer;
        transition: background 0.2s;
        font-weight: 500;
    }
    .btn-add:hover {
        background-color: #0056b3;
    }
</style>

<h2>Cửa hàng công nghệ</h2>

<div class="product-grid">
    <?php foreach ($products as $id => $p): ?>
    <div class="product-card">
        <img src="<?php echo $p['image']; ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" class="card-img">
        
        <div class="card-body">
            <h3 class="card-title"><?php echo htmlspecialchars($p['name']); ?></h3>
            <p class="card-desc"><?php echo htmlspecialchars($p['desc']); ?></p>
            
            <div class="card-footer">
                <span class="price"><?php echo number_format($p['price']); ?> đ</span>
                
                <form method="POST" action="">
                    <input type="hidden" name="product_id" value="<?php echo $id; ?>">
                    <button type="submit" name="add_to_cart" class="btn-add">
                        + Thêm
                    </button>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

</body></html>