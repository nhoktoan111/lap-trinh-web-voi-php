<?php
// [cite: 21] Luôn kiểm tra method
$errors = [];
$success = false;
$data_file = '../data/members.csv';

// Khởi tạo giá trị mặc định để tránh lỗi Undefined index [cite: 22]
$name = $email = $phone = $dob = $gender = $address = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lấy dữ liệu và trim
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? 'Khác';
    $address = trim($_POST['address'] ?? '');

    // --- VALIDATE DỮ LIỆU [cite: 37-40] ---
    
    // 1. Kiểm tra required
    if (empty($name)) $errors[] = "Họ tên là bắt buộc.";
    if (empty($email)) $errors[] = "Email là bắt buộc.";
    if (empty($phone)) $errors[] = "Số điện thoại là bắt buộc.";
    if (empty($dob)) $errors[] = "Ngày sinh là bắt buộc.";

    // 2. Validate Email
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email không đúng định dạng.";
    }

    // 3. Validate Số điện thoại (chỉ số, 9-11 ký tự) [cite: 40]
    if (!empty($phone) && (!is_numeric($phone) || strlen($phone) < 9 || strlen($phone) > 11)) {
        $errors[] = "Số điện thoại phải là số và từ 9-11 ký tự.";
    }

    // --- XỬ LÝ LƯU FILE [cite: 42] ---
    if (empty($errors)) {
        // Mở file mode 'a' (append) để thêm vào cuối
        $file = fopen($data_file, 'a');
        if ($file) {
            // Ghi dòng dữ liệu: Tên, Email, SĐT, Ngày sinh, Giới tính, Địa chỉ
            fputcsv($file, [$name, $email, $phone, $dob, $gender, $address]);
            fclose($file);
            $success = true;
            // Reset form sau khi thành công (tùy chọn)
            $name = $email = $phone = $dob = $address = '';
        } else {
            $errors[] = "Không thể mở file dữ liệu!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng ký thành viên</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>Đăng ký thẻ thư viện</h2>

    <?php if ($success): ?>
        <h3 class="success">Đăng ký thành công! Đã lưu vào CSV.</h3>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <ul class="error">
            <?php foreach ($errors as $err) echo "<li>$err</li>"; ?>
        </ul>
    <?php endif; ?>

    <form action="" method="POST">
        <div>
            <label>Họ tên (*):</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>">
        </div>
        <div>
            <label>Email (*):</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
        </div>
        <div>
            <label>Số điện thoại (*):</label>
            <input type="text" name="phone" value="<?php echo htmlspecialchars($phone); ?>">
        </div>
        <div>
            <label>Ngày sinh (*):</label>
            <input type="date" name="dob" value="<?php echo htmlspecialchars($dob); ?>">
        </div>
        <div>
            <label>Giới tính:</label>
            <label><input type="radio" name="gender" value="Nam" <?php echo ($gender=='Nam')?'checked':''; ?>> Nam</label>
            <label><input type="radio" name="gender" value="Nữ" <?php echo ($gender=='Nữ')?'checked':''; ?>> Nữ</label>
            <label><input type="radio" name="gender" value="Khác" <?php echo ($gender=='Khác')?'checked':''; ?>> Khác</label>
        </div>
        <div>
            <label>Địa chỉ:</label>
            <textarea name="address"><?php echo htmlspecialchars($address); ?></textarea>
        </div>
        <button type="submit">Đăng ký</button>
        <button type="reset">Làm lại</button>
    </form>
</body>
</html>