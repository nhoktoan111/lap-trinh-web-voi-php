<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kết quả đăng ký</title>
    <style>
        .error { color: red; }
        .success { color: green; }
        ul { list-style-type: disc; }
    </style>
</head>
<body>

<?php
// Kiểm tra xem người dùng có submit form chưa
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // 1. Khởi tạo mảng chứa lỗi
    $errors = [];
    
    // 2. Lấy dữ liệu từ form
    $full_name = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
    $email     = isset($_POST['email']) ? trim($_POST['email']) : '';
    $age       = isset($_POST['age']) ? trim($_POST['age']) : '';
    $gender    = isset($_POST['gender']) ? $_POST['gender'] : '';
    $hobbies   = isset($_POST['hobbies']) ? $_POST['hobbies'] : []; // Mảng hobbies
    $notes     = isset($_POST['notes']) ? trim($_POST['notes']) : '';

    // 3. Validate (Kiểm tra dữ liệu) - Đưa lỗi vào mảng $errors
    
    // - Kiểm tra Họ tên (required)
    if (empty($full_name)) {
        $errors[] = "Họ tên không được để trống.";
    }

    // - Kiểm tra Email (required, đúng định dạng)
    if (empty($email)) {
        $errors[] = "Email không được để trống.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email không đúng định dạng.";
    }

    // - Kiểm tra Tuổi (required, 10-80)
    if (empty($age)) {
        $errors[] = "Tuổi không được để trống.";
    } elseif (!is_numeric($age) || $age < 10 || $age > 80) {
        $errors[] = "Tuổi phải là số nằm trong khoảng từ 10 đến 80.";
    }

    // - Kiểm tra Giới tính (required - radio button)
    if (empty($gender)) {
        $errors[] = "Vui lòng chọn giới tính.";
    }

    // 4. Xử lý hiển thị
    if (!empty($errors)) {
        // --- TRƯỜNG HỢP CÓ LỖI ---
        echo "<h3>Đã có lỗi xảy ra:</h3>";
        echo "<ul class='error'>";
        foreach ($errors as $err) {
            echo "<li>$err</li>";
        }
        echo "</ul>";
        echo '<a href="index.php">Quay lại form</a>';
    } else {
        // --- TRƯỜNG HỢP THÀNH CÔNG ---
        echo "<h3 class='success'>Đăng ký thành công!</h3>";
        echo "<ul>";
        echo "<li><strong>Họ tên:</strong> $full_name</li>";
        echo "<li><strong>Email:</strong> $email</li>";
        echo "<li><strong>Tuổi:</strong> $age</li>";
        echo "<li><strong>Giới tính:</strong> $gender</li>";
        
        // Xử lý hiển thị sở thích (vì là mảng)
        $hobbies_str = !empty($hobbies) ? implode(", ", $hobbies) : "Không có";
        echo "<li><strong>Sở thích:</strong> $hobbies_str</li>";
        
        echo "<li><strong>Ghi chú:</strong> $notes</li>";
        echo "</ul>";
    }

} else {
    echo "Vui lòng submit từ form.";
}
?>

</body>
</html>