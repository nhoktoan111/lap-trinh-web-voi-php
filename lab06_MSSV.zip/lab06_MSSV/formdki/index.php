<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký Thông tin</title>
    <style>
        /* Reset CSS cơ bản */
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        /* Container dạng thẻ (Card) */
        .registration-form {
            background-color: #ffffff;
            width: 100%;
            max-width: 500px;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }

        /* Dấu sao đỏ cho trường bắt buộc */
        label .required {
            color: #e74c3c;
            margin-left: 3px;
        }

        /* Input styling */
        input[type="text"],
        input[type="email"],
        input[type="number"],
        textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        input:focus, textarea:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.2);
        }

        /* Styling cho Radio & Checkbox group */
        .radio-group, .checkbox-group {
            display: flex;
            gap: 20px;
            align-items: center;
            padding-top: 5px;
        }

        .radio-group label, .checkbox-group label {
            font-weight: normal;
            margin-bottom: 0;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        input[type="radio"], input[type="checkbox"] {
            transform: scale(1.2);
            cursor: pointer;
        }

        /* Nút Submit */
        button {
            width: 100%;
            padding: 14px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
        }

        button:hover {
            background-color: #2980b9;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .registration-form {
                padding: 20px;
                margin: 20px;
            }
        }
    </style>
</head>
<body>

    <div class="registration-form">
        <h2>Đăng Ký Thông Tin</h2>
        
        <form action="result.php" method="POST">
            
            <div class="form-group">
                <label for="full_name">Họ và tên <span class="required">*</span></label>
                <input type="text" id="full_name" name="full_name" placeholder="Nguyễn Văn A" required>
            </div>

            <div class="form-group">
                <label for="email">Email <span class="required">*</span></label>
                <input type="email" id="email" name="email" placeholder="example@domain.com" required>
            </div>

            <div class="form-group">
                <label for="age">Tuổi <span class="required">*</span></label>
                <input type="number" id="age" name="age" placeholder="Nhập tuổi (10-80)" min="10" max="80" required>
            </div>

            <div class="form-group">
                <label>Giới tính <span class="required">*</span></label>
                <div class="radio-group">
                    <label><input type="radio" name="gender" value="Nam" required> Nam</label>
                    <label><input type="radio" name="gender" value="Nữ"> Nữ</label>
                </div>
            </div>

            <div class="form-group">
                <label>Sở thích</label>
                <div class="checkbox-group">
                    <label><input type="checkbox" name="hobbies[]" value="Đọc sách"> Đọc sách</label>
                    <label><input type="checkbox" name="hobbies[]" value="Du lịch"> Du lịch</label>
                    <label><input type="checkbox" name="hobbies[]" value="Thể thao"> Thể thao</label>
                </div>
            </div>

            <div class="form-group">
                <label for="notes">Ghi chú thêm</label>
                <textarea id="notes" name="notes" rows="4" placeholder="Nhập ghi chú của bạn tại đây..."></textarea>
            </div>

            <button type="submit">Gửi Đăng Ký</button>
        </form>
    </div>

</body>
</html>