<?php
// Tạo thư mục invoices nếu chưa có
if (!is_dir('../data/invoices')) mkdir('../data/invoices', 0777, true);

$bill = null;
$errors = [];

// Khởi tạo biến mặc định để giữ dữ liệu (Sticky form)
$name = '';
$phone = '';
$payment = 'Tiền mặt';
$discount = 0;
$vat = 0;
// Mảng item mặc định rỗng để vòng lặp for bên dưới không lỗi
$items_input = []; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Lấy thông tin khách
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $payment = $_POST['payment'] ?? 'Tiền mặt';
    $discount = $_POST['discount'] ?? 0;
    $vat = $_POST['vat'] ?? 0;
    
    // Lấy raw items để repopulate vào form nếu lỗi
    $items_input = $_POST['items'] ?? [];

    $customer = [
        'name' => $name,
        'phone' => $phone,
        'payment' => $payment
    ];

    if (empty($phone)) $errors[] = "Số điện thoại là bắt buộc.";

    // 2. Xử lý danh sách hàng hóa
    $validItems = [];
    $subTotal = 0;

    foreach ($items_input as $item) {
        $itemName = trim($item['name'] ?? '');
        $qty = floatval($item['qty'] ?? 0);
        $price = floatval($item['price'] ?? 0);

        // Chỉ xử lý dòng có dữ liệu hợp lệ
        if (!empty($itemName) && $qty > 0 && $price > 0) {
            $rowTotal = $qty * $price;
            $subTotal += $rowTotal;
            
            $validItems[] = [
                'name' => $itemName,
                'qty' => $qty,
                'price' => $price,
                'total' => $rowTotal
            ];
        }
    }

    if (empty($validItems)) $errors[] = "Phải nhập ít nhất 1 mặt hàng hợp lệ (Tên, SL > 0, Giá > 0).";

    // 3. Tính toán tổng
    if (empty($errors)) {
        $discountPercent = floatval($discount);
        $vatPercent = floatval($vat);

        $discountAmount = $subTotal * ($discountPercent / 100);
        $afterDiscount = $subTotal - $discountAmount;
        $vatAmount = $afterDiscount * ($vatPercent / 100);
        $grandTotal = $afterDiscount + $vatAmount;

        // Chuẩn bị dữ liệu hóa đơn
        $bill = [
            'customer' => $customer,
            'items' => $validItems,
            'math' => [
                'sub_total' => $subTotal,
                'discount_percent' => $discountPercent,
                'discount_amt' => $discountAmount,
                'vat_percent' => $vatPercent,
                'vat_amt' => $vatAmount,
                'grand_total' => $grandTotal
            ],
            'date' => date('Y-m-d H:i:s')
        ];

        // 4. Lưu file JSON 
        $fileName = '../data/invoices/invoice_' . time() . '.json';
        file_put_contents($fileName, json_encode($bill, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tạo hóa đơn</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* CSS riêng cho Hóa đơn để ghi đè style chung khi cần */
        .invoice-box { 
            background: #fff;
            border: 1px solid #ddd; 
            padding: 30px; 
            margin: 20px auto; /* Canh giữa */
            max-width: 700px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .text-right { text-align: right; }
        
        /* Style cho hàng nhập liệu (Item row) */
        .item-row {
            display: flex; /* Xếp ngang */
            gap: 10px;     /* Khoảng cách giữa các ô */
            margin-bottom: 10px;
            align-items: center;
        }
        /* Chỉnh độ rộng từng ô input trong hàng */
        .item-row input[name*="[name]"] { flex: 2; margin-bottom: 0; } /* Tên hàng rộng nhất */
        .item-row input[name*="[qty]"] { width: 70px; margin-bottom: 0; }
        .item-row input[name*="[price]"] { flex: 1; margin-bottom: 0; }
        .item-row label { margin: 0; min-width: 20px; font-weight: bold; color: #888;}
    </style>
</head>
<body>
    <h2>Tạo Hóa Đơn Bán Hàng</h2>
    
    <?php if (!empty($errors)): ?>
        <div class="error">
            <ul><?php foreach($errors as $e) echo "<li>$e</li>"; ?></ul>
        </div>
    <?php endif; ?>

    <form method="POST">
        <h3>1. Thông tin khách hàng</h3>
        <div>
            <label>Họ tên:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($name) ?>">
        </div>
        <div>
            <label>Số điện thoại (*):</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($phone) ?>" required>
        </div>
        <div>
            <label>Thanh toán:</label>
            <label><input type="radio" name="payment" value="Tiền mặt" <?= $payment=='Tiền mặt'?'checked':'' ?>> Tiền mặt</label>
            <label><input type="radio" name="payment" value="Chuyển khoản" <?= $payment=='Chuyển khoản'?'checked':'' ?>> Chuyển khoản</label>
        </div>

        <h3>2. Danh sách hàng hóa</h3>
        <p style="font-size: 0.9em; color: #666; margin-bottom: 10px;">(Nhập tối đa 3 mặt hàng. Bỏ trống nếu không dùng)</p>
        
        <div class="item-row" style="font-weight: bold; font-size: 14px; margin-bottom: 5px;">
            <span style="min-width: 20px">#</span>
            <span style="flex: 2">Tên hàng hóa</span>
            <span style="width: 70px">SL</span>
            <span style="flex: 1">Đơn giá (VNĐ)</span>
        </div>

        <?php for($i=0; $i<3; $i++): 
            // Lấy lại giá trị cũ nếu có lỗi
            $iName = $items_input[$i]['name'] ?? '';
            $iQty = $items_input[$i]['qty'] ?? '';
            $iPrice = $items_input[$i]['price'] ?? '';
        ?>
        <div class="item-row">
            <label><?= $i+1 ?></label>
            <input type="text" name="items[<?= $i ?>][name]" value="<?= htmlspecialchars($iName) ?>" placeholder="Tên hàng...">
            <input type="number" name="items[<?= $i ?>][qty]" value="<?= htmlspecialchars($iQty) ?>" placeholder="0">
            <input type="number" name="items[<?= $i ?>][price]" value="<?= htmlspecialchars($iPrice) ?>" placeholder="0">
        </div>
        <?php endfor; ?>

        <h3>3. Chiết khấu & VAT</h3>
        <div style="display: flex; gap: 20px;">
            <div style="flex: 1">
                <label>Giảm giá (%):</label>
                <input type="number" name="discount" value="<?= htmlspecialchars($discount) ?>" min="0" max="100">
            </div>
            <div style="flex: 1">
                <label>VAT (%):</label>
                <input type="number" name="vat" value="<?= htmlspecialchars($vat) ?>" min="0" max="100">
            </div>
        </div>
        
        <br>
        <button type="submit">Tạo hóa đơn</button>
    </form>

    <?php if ($bill): ?>
    <div class="invoice-box">
        <h3 style="text-align:center; border-bottom:none; display:block">HÓA ĐƠN BÁN LẺ</h3>
        <div style="border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 20px;">
            <p><strong>Khách hàng:</strong> <?= htmlspecialchars($bill['customer']['name']) ?> 
               (<?= htmlspecialchars($bill['customer']['phone']) ?>)</p>
            <p><strong>Ngày lập:</strong> <?= date('d/m/Y H:i', strtotime($bill['date'])) ?></p>
            <p><strong>HTTT:</strong> <?= $bill['customer']['payment'] ?></p>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>Tên hàng</th>
                    <th class="text-right">SL</th>
                    <th class="text-right">Đơn giá</th>
                    <th class="text-right">Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bill['items'] as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['name']) ?></td>
                    <td class="text-right"><?= $item['qty'] ?></td>
                    <td class="text-right"><?= number_format($item['price']) ?></td>
                    <td class="text-right"><?= number_format($item['total']) ?></td>
                </tr>
                <?php endforeach; ?>
                
                <tr><td colspan="4" style="border:none; height: 10px;"></td></tr>

                <tr style="background: #fff;">
                    <td colspan="3" class="text-right">Tạm tính:</td>
                    <td class="text-right"><?= number_format($bill['math']['sub_total']) ?></td>
                </tr>
                <tr style="background: #fff;">
                    <td colspan="3" class="text-right" style="color: #e67e22">Giảm giá (<?= $bill['math']['discount_percent'] ?>%):</td>
                    <td class="text-right">-<?= number_format($bill['math']['discount_amt']) ?></td>
                </tr>
                <tr style="background: #fff;">
                    <td colspan="3" class="text-right" style="color: #7f8c8d">VAT (<?= $bill['math']['vat_percent'] ?>%):</td>
                    <td class="text-right">+<?= number_format($bill['math']['vat_amt']) ?></td>
                </tr>
                <tr style="font-size: 1.2em; background: #ecf0f1;">
                    <td colspan="3" class="text-right"><strong>TỔNG THANH TOÁN:</strong></td>
                    <td class="text-right" style="color: #c0392b"><strong><?= number_format($bill['math']['grand_total']) ?> đ</strong></td>
                </tr>
            </tbody>
        </table>
        
        <p style="text-align:center; margin-top: 30px; font-style: italic; color: #888;">Cảm ơn quý khách!</p>
    </div>
    <?php endif; ?>

</body>
</html>