<?php
$json_file = '../data/books.json';
$errors = [];
$success = "";

// Giá trị mặc định
$code = $title = $author = $year = $category = $qty = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Lấy dữ liệu
    $code = trim($_POST['code'] ?? '');
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $year = $_POST['year'] ?? '';
    $category = $_POST['category'] ?? 'Khác';
    $qty = $_POST['qty'] ?? 0;

    // 2. Validate cơ bản
    if (empty($code) || empty($title) || empty($author)) {
        $errors[] = "Vui lòng nhập Mã, Tên sách và Tác giả.";
    }

    // Validate Năm (phải là số và hợp lý)
    if (!empty($year) && ($year < 1900 || $year > date('Y') + 1)) {
        $errors[] = "Năm xuất bản không hợp lệ.";
    }

    // 3. Validate Logic: Kiểm tra trùng mã sách
    // Đọc dữ liệu cũ lên để so sánh
    $current_books = [];
    if (file_exists($json_file)) {
        $current_books = json_decode(file_get_contents($json_file), true) ?? [];
    }

    foreach ($current_books as $book) {
        if ($book['code'] === $code) {
            $errors[] = "Mã sách '$code' đã tồn tại! Vui lòng chọn mã khác.";
            break; 
        }
    }

    // 4. Lưu file nếu không lỗi
    if (empty($errors)) {
        $new_book = [
            'code' => $code,
            'title' => $title,
            'author' => $author,
            'year' => $year,
            'category' => $category,
            'qty' => (int)$qty
        ];

        // Thêm sách mới vào mảng
        $current_books[] = $new_book;

        // Ghi đè lại file JSON
        // JSON_PRETTY_PRINT: để file dễ đọc
        // JSON_UNESCAPED_UNICODE: để không bị lỗi font tiếng Việt
        if (file_put_contents($json_file, json_encode($current_books, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
            $success = "Thêm sách thành công!";
            // Reset form
            $code = $title = $author = $year = $qty = ''; 
        } else {
            $errors[] = "Lỗi khi ghi file dữ liệu.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm sách mới</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>Thêm sách vào kho</h2>
    
    <a href="list_books.php">← Quay lại danh sách</a>
    <br><br>

    <?php if ($success): ?>
        <div class="success"><?= $success ?></div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <ul class="error">
            <?php foreach ($errors as $e) echo "<li>$e</li>"; ?>
        </ul>
    <?php endif; ?>

    <form method="POST" action="">
        <div>
            <label>Mã sách (*):</label>
            <input type="text" name="code" value="<?= htmlspecialchars($code) ?>" placeholder="Ví dụ: IT01">
        </div>

        <div>
            <label>Tên sách (*):</label>
            <input type="text" name="title" value="<?= htmlspecialchars($title) ?>">
        </div>

        <div>
            <label>Tác giả (*):</label>
            <input type="text" name="author" value="<?= htmlspecialchars($author) ?>">
        </div>

        <div>
            <label>Năm xuất bản:</label>
            <input type="number" name="year" value="<?= htmlspecialchars($year) ?>">
        </div>

        <div>
            <label>Thể loại:</label>
            <select name="category">
                <option value="Giáo trình" <?= $category=='Giáo trình'?'selected':'' ?>>Giáo trình</option>
                <option value="Văn học" <?= $category=='Văn học'?'selected':'' ?>>Văn học</option>
                <option value="Khoa học" <?= $category=='Khoa học'?'selected':'' ?>>Khoa học</option>
                <option value="Kỹ năng" <?= $category=='Kỹ năng'?'selected':'' ?>>Kỹ năng</option>
                <option value="Khác" <?= $category=='Khác'?'selected':'' ?>>Khác</option>
            </select>
        </div>

        <div>
            <label>Số lượng:</label>
            <input type="number" name="qty" value="<?= htmlspecialchars($qty) ?>" min="0">
        </div>

        <button type="submit">Lưu sách</button>
    </form>
</body>
</html>