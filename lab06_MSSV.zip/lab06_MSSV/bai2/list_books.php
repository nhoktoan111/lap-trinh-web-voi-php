<?php
// Đường dẫn file dữ liệu
$json_file = '../data/books.json';
$books = [];

// Kiểm tra file có tồn tại không trước khi đọc
if (file_exists($json_file)) {
    $json_content = file_get_contents($json_file);
    // decode: chuyển chuỗi JSON thành mảng PHP (true = mảng kết hợp)
    $books = json_decode($json_content, true) ?? [];
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách sách</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* CSS riêng cho bài này nếu cần */
        .out-of-stock { color: red; font-weight: bold; }
        .btn-add { display: inline-block; margin-bottom: 15px; }
    </style>
</head>
<body>
    <h2>Kho sách thư viện</h2>
    
    <a href="add_book.php" class="btn-add">
        <button type="button">+ Thêm sách mới</button>
    </a>

    <?php if (empty($books)): ?>
        <p class="error">Hiện chưa có cuốn sách nào trong kho dữ liệu.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã sách</th>
                    <th>Tên sách</th>
                    <th>Tác giả</th>
                    <th>Năm XB</th>
                    <th>Thể loại</th>
                    <th>Số lượng</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $stt = 1;
                foreach ($books as $b): 
                    // Kiểm tra số lượng để cảnh báo
                    $qtyClass = ($b['qty'] <= 0) ? 'out-of-stock' : '';
                ?>
                <tr>
                    <td><?= $stt++ ?></td>
                    <td><?= htmlspecialchars($b['code']) ?></td>
                    <td><?= htmlspecialchars($b['title']) ?></td>
                    <td><?= htmlspecialchars($b['author']) ?></td>
                    <td><?= htmlspecialchars($b['year']) ?></td>
                    <td><?= htmlspecialchars($b['category']) ?></td>
                    
                    <td class="<?= $qtyClass ?>">
                        <?= $b['qty'] ?>
                        <?= ($b['qty'] <= 0) ? '(Hết hàng)' : '' ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <p>Tổng số đầu sách: <b><?= count($books) ?></b></p>
    <?php endif; ?>
</body>
</html>