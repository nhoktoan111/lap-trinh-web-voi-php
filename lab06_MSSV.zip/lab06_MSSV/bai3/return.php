<?php
$file_books = '../data/books.json';
$file_borrows = '../data/borrows.json';
$msg = '';
$error = '';

// Khởi tạo biến để tránh lỗi undefined ở HTML và hỗ trợ Sticky form
$borrowId = '';

function readJson($path) {
    return file_exists($path) ? json_decode(file_get_contents($path), true) : [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $borrowId = trim($_POST['borrow_id'] ?? '');
    
    $borrows = readJson($file_borrows);
    $books = readJson($file_books);
    
    $borrowIndex = -1;
    // Tìm phiếu mượn
    foreach ($borrows as $index => $br) {
        // Kiểm tra đúng mã và trạng thái đang mượn
        if ($br['id'] === $borrowId && $br['status'] === 'borrowing') {
            $borrowIndex = $index;
            break;
        }
    }

    if ($borrowIndex === -1) {
        $error = "Phiếu mượn không tồn tại hoặc sách đã được trả!";
    } else {
        // --- XỬ LÝ TRẢ THÀNH CÔNG ---
        
        // 1. Cập nhật trạng thái phiếu
        $borrows[$borrowIndex]['status'] = 'returned';
        $borrows[$borrowIndex]['return_date'] = date('Y-m-d');
        
        // 2. Tăng số lượng sách trong kho
        $bookCodeReturned = $borrows[$borrowIndex]['book_code'];
        foreach ($books as &$b) { // Dùng tham chiếu & để sửa trực tiếp
            if ($b['code'] === $bookCodeReturned) {
                $b['qty']++;
                break;
            }
        }
        
        // Lưu lại file
        file_put_contents($file_borrows, json_encode($borrows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        file_put_contents($file_books, json_encode($books, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        $msg = "Trả sách thành công!";
        
        // Reset ô nhập liệu sau khi thành công
        $borrowId = '';
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Trả sách</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>Trả sách thư viện</h2>
    
    <?php if($msg): ?>
        <div class="success"><?= $msg ?></div>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div>
            <label>Nhập mã phiếu mượn (*):</label>
            <input type="text" name="borrow_id" 
                   value="<?= htmlspecialchars($borrowId) ?>" 
                   placeholder="Ví dụ: BR_659c..." required>
        </div>
        <button type="submit">Xác nhận trả</button>
        
        <a href="borrow.php" style="margin-left: 10px; font-weight: normal; font-size: 14px;">
            ← Quay lại Mượn sách
        </a>
    </form>
    
    <hr style="margin: 30px 0; border: 0; border-top: 1px solid #ccc;">

    <h3>Danh sách đang mượn (Gợi ý test):</h3>
    
    <?php 
    $allBorrows = readJson($file_borrows);
    // Lọc ra danh sách đang mượn
    $borrowingList = array_filter($allBorrows, function($b) {
        return $b['status'] == 'borrowing';
    });
    ?>

    <?php if(empty($borrowingList)): ?>
        <p>Hiện không có phiếu mượn nào cần trả.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Mã phiếu</th>
                    <th>Sách</th>
                    <th>Thành viên</th>
                    <th>Ngày mượn</th>
                    <th>Copy mã</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($borrowingList as $b): ?>
                <tr>
                    <td style="font-weight:bold; color:#2980b9"><?= $b['id'] ?></td>
                    <td><?= $b['book_code'] ?></td>
                    <td><?= $b['member_code'] ?></td>
                    <td><?= $b['borrow_date'] ?></td>
                    <td style="font-size: 12px; color: #888;">
                        (Copy mã ở cột 1)
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

</body>
</html>