<?php
// Đường dẫn file dữ liệu
$file_books = '../data/books.json';
$file_members = '../data/members.csv';
$file_borrows = '../data/borrows.json';

$msg = '';
$error = '';

// --- KHỞI TẠO BIẾN (Quan trọng để không lỗi Undefined Variable ở HTML) ---
$member_code = '';
$book_code = '';

// Hàm đọc JSON
function readJson($path) {
    return file_exists($path) ? json_decode(file_get_contents($path), true) : [];
}

// Hàm đọc CSV (Thành viên)
function getMembers($path) {
    $members = [];
    if (file_exists($path) && ($handle = fopen($path, "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if(isset($data[2])) $members[] = trim($data[2]); 
        }
        fclose($handle);
    }
    return $members;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // --- SỬA LỖI TẠI ĐÂY: Dùng đúng tên biến $member_code và $book_code ---
    $member_code = trim($_POST['member_code'] ?? ''); 
    $book_code = trim($_POST['book_code'] ?? '');
    
    $members = getMembers($file_members);
    $books = readJson($file_books);
    $borrows = readJson($file_borrows);

    // 1. Validate Thành viên 
    if (!in_array($member_code, $members)) { // Sửa $phone thành $member_code
        $error = "Thành viên (SĐT: $member_code) không tồn tại!";
    } 
    else {
        // 2. Validate Sách & Số lượng 
        $bookIndex = -1;
        foreach ($books as $index => $b) {
            if ($b['code'] === $book_code) { // Sửa $bookCode thành $book_code
                $bookIndex = $index;
                break;
            }
        }

        if ($bookIndex === -1) {
            $error = "Mã sách không tồn tại!";
        } elseif ($books[$bookIndex]['qty'] <= 0) {
            $error = "Sách này đã hết, không thể mượn!";
        } else {
            // --- XỬ LÝ MƯỢN THÀNH CÔNG ---
            
            // Bước 1: Giảm số lượng sách
            $books[$bookIndex]['qty']--;
            file_put_contents($file_books, json_encode($books, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

            // Bước 2: Tạo phiếu mượn 
            $newBorrow = [
                'id' => uniqid('BR'),
                'member_code' => $member_code, // Sửa biến
                'book_code' => $book_code,     // Sửa biến
                'borrow_date' => date('Y-m-d'),
                'status' => 'borrowing'
            ];
            $borrows[] = $newBorrow;
            file_put_contents($file_borrows, json_encode($borrows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

            $msg = "Mượn sách thành công! Mã phiếu: " . $newBorrow['id'];
            
            // Reset form sau khi thành công (để ô input trống lại cho lượt mượn tiếp)
            $member_code = '';
            $book_code = '';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Mượn sách</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>Lập phiếu mượn sách</h2>

    <?php if($msg): ?>
        <div class="success"><?= $msg ?></div>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div>
            <label>Số điện thoại thành viên (*):</label>
            <input type="text" name="member_code" 
                   value="<?= htmlspecialchars($member_code) ?>" 
                   placeholder="Nhập SĐT thành viên..." required>
        </div>
        
        <div>
            <label>Mã sách (*):</label>
            <input type="text" name="book_code" 
                   value="<?= htmlspecialchars($book_code) ?>" 
                   placeholder="Nhập mã sách (VD: PHP01)..." required>
        </div>
        
        <button type="submit">Xác nhận mượn</button>
    </form>
    
    <br>
    <div style="margin-left: 20px;">
        <p>Muốn trả sách?</p>
        <a href="return.php">
            <button type="button" style="background-color: #27ae60;">→ Chuyển sang Trả sách</button>
        </a>
    </div>
</body>
</html>