<?php
// 1. Đọc dữ liệu từ file JSON chung
$json_file = '../data/books.json';
$books = [];
if (file_exists($json_file)) {
    $books = json_decode(file_get_contents($json_file), true) ?? [];
}

// Khởi tạo biến tìm kiếm
$kw = '';
$category_filter = '';
$results = []; // Mặc định rỗng
$is_searching = false; // Cờ kiểm tra xem người dùng có đang tìm kiếm không

// 2. Xử lý logic Tìm kiếm (Phương thức GET)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && (isset($_GET['kw']) || isset($_GET['category']))) {
    $is_searching = true;
    
    // Lấy dữ liệu từ URL
    $kw = trim($_GET['kw'] ?? '');
    $category_filter = $_GET['category'] ?? 'all';

    // Duyệt qua danh sách sách để lọc
    foreach ($books as $b) {
        // A. Kiểm tra từ khóa (trong Tên sách HOẶC Tác giả)
        $matchKw = false;
        if ($kw === '') {
            $matchKw = true; 
        } else {
            // stripos: tìm kiếm không phân biệt hoa thường
            if (stripos($b['title'], $kw) !== false || stripos($b['author'], $kw) !== false) {
                $matchKw = true;
            }
        }

        // B. Kiểm tra thể loại
        $matchCat = false;
        if ($category_filter === '' || $category_filter === 'all') {
            $matchCat = true; 
        } elseif ($b['category'] === $category_filter) {
            $matchCat = true;
        }

        // C. Nếu thỏa mãn cả 2 điều kiện
        if ($matchKw && $matchCat) {
            $results[] = $b;
        }
    }
} else {
    // Nếu mới vào trang (chưa tìm), hiển thị tất cả sách
    $results = $books;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tìm kiếm sách</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* Style riêng cho nút Xóa bộ lọc */
        .btn-secondary {
            background-color: #95a5a6;
            margin-left: 10px;
        }
        .btn-secondary:hover {
            background-color: #7f8c8d;
        }
        /* Style cho chữ báo hết hàng */
        .out-of-stock {
            color: #e74c3c;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2>Tra cứu sách thư viện</h2>

    <form action="" method="GET">
        <div>
            <label>Từ khóa (Tên sách/Tác giả):</label>
            <input type="text" name="kw" 
                   value="<?php echo htmlspecialchars($kw); ?>" 
                   placeholder="Nhập từ khóa tìm kiếm...">
        </div>
        
        <div>
            <label>Thể loại:</label>
            <select name="category">
                <option value="all">-- Tất cả thể loại --</option>
                <option value="Giáo trình" <?php if($category_filter == 'Giáo trình') echo 'selected'; ?>>Giáo trình</option>
                <option value="Văn học" <?php if($category_filter == 'Văn học') echo 'selected'; ?>>Văn học</option>
                <option value="Khoa học" <?php if($category_filter == 'Khoa học') echo 'selected'; ?>>Khoa học</option>
                <option value="Kỹ năng" <?php if($category_filter == 'Kỹ năng') echo 'selected'; ?>>Kỹ năng</option>
                <option value="Khác" <?php if($category_filter == 'Khác') echo 'selected'; ?>>Khác</option>
            </select>
        </div>

        <div style="margin-top: 10px;">
            <button type="submit">🔍 Tìm kiếm</button>
            
            <?php if($is_searching): ?>
                <a href="search.php">
                    <button type="button" class="btn-secondary">✖ Xóa bộ lọc</button>
                </a>
            <?php endif; ?>
        </div>
    </form>

    <hr style="border: 0; border-top: 1px solid #ddd; margin: 30px 0;">

    <?php if (empty($results) && $is_searching): ?>
        <div class="error">
            Không tìm thấy sách nào phù hợp với từ khóa "<b><?= htmlspecialchars($kw) ?></b>"!
        </div>
    <?php else: ?>
        <p>
            <?php if($is_searching): ?>
                Kết quả tìm kiếm: Tìm thấy <b><?= count($results) ?></b> cuốn sách.
            <?php else: ?>
                Danh sách toàn bộ sách (<b><?= count($results) ?></b> cuốn):
            <?php endif; ?>
        </p>
        
        <table>
            <thead>
                <tr>
                    <th>Mã sách</th>
                    <th>Tên sách</th>
                    <th>Tác giả</th>
                    <th>Năm XB</th>
                    <th>Thể loại</th>
                    <th>Tồn kho</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $b): ?>
                <tr>
                    <td><?= htmlspecialchars($b['code']) ?></td>
                    <td><?= htmlspecialchars($b['title']) ?></td>
                    <td><?= htmlspecialchars($b['author']) ?></td>
                    <td><?= htmlspecialchars($b['year']) ?></td>
                    <td><?= htmlspecialchars($b['category']) ?></td>
                    
                    <td class="<?= $b['qty'] == 0 ? 'out-of-stock' : '' ?>">
                        <?= $b['qty'] ?>
                        <?= $b['qty'] == 0 ? '(Hết)' : '' ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

</body>
</html>