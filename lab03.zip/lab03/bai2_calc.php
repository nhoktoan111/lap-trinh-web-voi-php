<?php
// bai2_calc.php

// Lấy tham số a, b, op [cite: 48]
$a = isset($_GET["a"]) ? (float)$_GET["a"] : 0;
$b = isset($_GET["b"]) ? (float)$_GET["b"] : 0;
$op = $_GET["op"] ?? "add"; // Mặc định là cộng

$result = 0;
$op_symbol = "";
$error = "";

// Xử lý switch-case [cite: 49]
switch ($op) {
    case 'add':
        $result = $a + $b;
        $op_symbol = "+";
        break;
    case 'sub':
        $result = $a - $b;
        $op_symbol = "-";
        break;
    case 'mul':
        $result = $a * $b;
        $op_symbol = "*";
        break;
    case 'div':
        // Kiểm tra chia cho 0 [cite: 50]
        if ($b == 0) {
            $error = "Không thể chia cho 0";
        } else {
            $result = $a / $b;
            $op_symbol = "/";
        }
        break;
    default:
        $error = "Toán tử không hợp lệ (chỉ chấp nhận: add, sub, mul, div)";
}

echo "<h2>Bài 2: Máy tính Mini</h2>";
echo "Tham số test: <a href='?a=10&b=5&op=add'>10 + 5</a> | <a href='?a=10&b=0&op=div'>10 / 0</a><br><br>";

if ($error) {
    echo "<span style='color:red'>Lỗi: $error</span>";
} else {
    // Hiển thị kết quả [cite: 51]
    echo "Kết quả: $a $op_symbol $b = <b>$result</b>";
}
?>