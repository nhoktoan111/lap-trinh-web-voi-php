<?php
// bai3_loops.php
$n = isset($_GET["n"]) ? (int)$_GET["n"] : 0;

echo "<h2>Bài 3: Vòng lặp</h2>";
echo "Test: <a href='?n=12345'>n=12345</a> | <a href='?n=20'>n=20</a><hr>";

// YÊU CẦU B: Tính tổng chữ số của n (dùng while) [cite: 68]
if ($n > 0) {
    echo "<h3>B) Tổng chữ số của n = $n</h3>";
    $temp = $n;
    $sum = 0;
    while ($temp > 0) {
        $digit = $temp % 10;
        $sum += $digit;
        $temp = (int)($temp / 10);
    }
    echo "Tổng các chữ số là: <b>$sum</b>";
}

// YÊU CẦU C: In số lẻ từ 1..N, dừng nếu > 15 (break/continue) [cite: 69]
if ($n > 0) {
    echo "<h3>C) Các số lẻ từ 1 đến $n (Dừng nếu > 15)</h3>";
    for ($i = 1; $i <= $n; $i++) {
        // Dùng continue để bỏ qua số chẵn
        if ($i % 2 == 0) continue;
        
        // Dùng break để dừng sớm khi vượt 15
        if ($i > 15) {
            echo "... (Dừng do vượt quá 15)";
            break;
        }
        echo "$i ";
    }
}

// YÊU CẦU A: Bảng cửu chương (dùng for lồng nhau) [cite: 67]
echo "<h3>A) Bảng cửu chương 1-9</h3>";
echo "<table border='1' cellpadding='5' cellspacing='0'>";
for ($i = 1; $i <= 9; $i++) {
    echo "<tr>";
    for ($j = 1; $j <= 9; $j++) {
        echo "<td>$i x $j = " . ($i * $j) . "</td>";
    }
    echo "</tr>";
}
echo "</table>";
?>