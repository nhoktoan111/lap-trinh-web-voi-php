<?php
// functions.php

// 1. Hàm tìm số lớn nhất
function max2($a, $b) {
    return ($a > $b) ? $a : $b;
}

// 1. Hàm tìm số nhỏ nhất
function min2($a, $b) {
    return ($a < $b) ? $a : $b;
}

// 2. Hàm kiểm tra số nguyên tố
function isPrime(int $n): bool {
    if ($n < 2) return false;
    for ($i = 2; $i <= sqrt($n); $i++) {
        if ($n % $i == 0) return false;
    }
    return true;
}

// 3. Hàm tính giai thừa (n >= 0 trả về giai thừa, n < 0 trả về null)
function factorial(int $n) {
    if ($n < 0) return null;
    if ($n == 0 || $n == 1) return 1;
    
    $result = 1;
    for ($i = 2; $i <= $n; $i++) {
        $result *= $i;
    }
    return $result;
}

// 4. Hàm tìm ƯCLN (GCD) theo thuật toán Euclid
function gcd(int $a, int $b): int {
    $a = abs($a); // Lấy trị tuyệt đối để tránh lỗi số âm
    $b = abs($b);
    while ($b != 0) {
        $r = $a % $b;
        $a = $b;
        $b = $r;
    }
    return $a;
}
?>