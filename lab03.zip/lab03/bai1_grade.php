<?php
// bai1_grade.php

// Lấy tham số score từ URL, nếu không có thì gán null
$score = isset($_GET["score"]) ? (float)$_GET["score"] : null;

echo "<h2>Bài 1: Phân loại điểm</h2>";

// Kiểm tra nếu chưa nhập score
if ($score === null && !isset($_GET["score"])) {
    echo "Vui lòng truyền tham số lên URL. Ví dụ: <a href='?score=8.5'>?score=8.5</a>";
    exit;
}

// Kiểm tra hợp lệ 0 <= score <= 10 [cite: 34]
if ($score < 0 || $score > 10) {
    echo "Điểm không hợp lệ! Điểm phải từ 0 đến 10.";
} else {
    // Phân loại [cite: 35]
    $rank = "";
    if ($score >= 8.5) {
        $rank = "Giỏi";
    } elseif ($score >= 7.0) {
        $rank = "Khá";
    } elseif ($score >= 5.0) {
        $rank = "Trung bình";
    } else {
        $rank = "Yếu";
    }
    
    // Hiển thị kết quả [cite: 36]
    echo "Điểm: $score – Xếp loại: <b>$rank</b>";
}
?>