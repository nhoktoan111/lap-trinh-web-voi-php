<?php
// index.php
require_once "functions.php"; // [cite: 100]

$action = $_GET["action"] ?? "home";
$a = isset($_GET["a"]) ? (int)$_GET["a"] : 0;
$b = isset($_GET["b"]) ? (int)$_GET["b"] : 0;
$n = isset($_GET["n"]) ? (int)$_GET["n"] : 0;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Lab 03 - PHP Basic</title>
</head>
<body>
    <h1>LAB03: Cấu trúc điều khiển và Hàm</h1>
    
    <p>
        <b>Bài tập riêng lẻ:</b>
        <a href="bai1_grade.php">Bài 1 (Điểm)</a> |
        <a href="bai2_calc.php">Bài 2 (Máy tính)</a> |
        <a href="bai3_loops.php">Bài 3 (Vòng lặp)</a>
    </p>
    
    <hr>
    
    <h2>Test Function (Bài 4 & 5)</h2>
    <p>
        <a href='?action=max&a=10&b=22'>Max (10, 22)</a> |
        <a href='?action=min&a=10&b=22'>Min (10, 22)</a> |
        <a href='?action=prime&n=17'>Is Prime (17)</a> |
        <a href='?action=prime&n=10'>Is Prime (10)</a> |
        <a href='?action=fact&n=6'>Factorial (6)</a> |
        <a href='?action=gcd&a=12&b=18'>GCD (12, 18)</a>
    </p>

    <div style="border: 1px solid #ccc; padding: 10px; background: #f9f9f9;">
    <?php
    // Xử lý action [cite: 108]
    switch ($action) {
        case 'max':
            echo "Max của $a và $b là: <b>" . max2($a, $b) . "</b>";
            break;
            
        case 'min':
            echo "Min của $a và $b là: <b>" . min2($a, $b) . "</b>";
            break;
            
        case 'prime':
            $check = isPrime($n) ? "Đúng" : "Sai";
            echo "Số $n là số nguyên tố? -> <b>$check</b>";
            break;
            
        case 'fact':
            $res = factorial($n);
            if ($res === null) echo "Không tính giai thừa cho số âm.";
            else echo "Giai thừa của $n là: <b>$res</b>";
            break;
            
        case 'gcd':
            echo "Ước chung lớn nhất của $a và $b là: <b>" . gcd($a, $b) . "</b>";
            break;
            
        case 'home':
            echo "Vui lòng chọn chức năng ở trên để test.";
            break;
            
        default:
            echo "Chức năng không tồn tại.";
    }
    ?>
    </div>

</body>
</html>