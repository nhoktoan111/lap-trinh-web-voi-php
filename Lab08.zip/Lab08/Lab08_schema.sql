-- Tạo CSDL
DROP DATABASE IF EXISTS ql_thu_vien;
CREATE DATABASE ql_thu_vien CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ql_thu_vien;

-- 1. Bảng categories (Danh mục)
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL -- [cite: 18, 29]
);

-- 2. Bảng publishers (Nhà xuất bản)
CREATE TABLE publishers (
    publisher_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL -- [cite: 19, 29]
);

-- 3. Bảng books (Sách)
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category_id INT,
    publisher_id INT,
    price DECIMAL(10, 2) CHECK (price > 0), -- [cite: 30]
    published_year INT,
    stock INT CHECK (stock >= 0), -- [cite: 30]
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    FOREIGN KEY (publisher_id) REFERENCES publishers(publisher_id)
);

-- 4. Bảng members (Thành viên/Độc giả)
CREATE TABLE members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL, -- [cite: 21, 29]
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 5. Bảng loans (Phiếu mượn)
CREATE TABLE loans (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT,
    loan_date DATE NOT NULL,
    due_date DATE NOT NULL,
    status ENUM('BORROWED', 'RETURNED', 'OVERDUE') DEFAULT 'BORROWED',
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE RESTRICT -- [cite: 28]
);

-- 6. Bảng loan_items (Chi tiết phiếu mượn)
CREATE TABLE loan_items (
    loan_id INT,
    book_id INT,
    qty INT CHECK (qty > 0), -- [cite: 30]
    PRIMARY KEY (loan_id, book_id),
    FOREIGN KEY (loan_id) REFERENCES loans(loan_id) ON DELETE CASCADE, -- [cite: 28]
    FOREIGN KEY (book_id) REFERENCES books(book_id)
);